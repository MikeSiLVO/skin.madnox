# skin.madnox.redux
 Picking up the torch for Mr. V's Kodi Skin Madnox

 ![1](https://i.postimg.cc/Vv3CkMrM/1.png)
 
 ![2](https://i.postimg.cc/cHL9RqDh/11.png)
 
 ![3](https://i.postimg.cc/T3jDTKRL/7.png)

 ![4](https://i.postimg.cc/ZKBPzYBp/2.png)

 ![5](https://i.postimg.cc/FzjL1zjB/3.png)
